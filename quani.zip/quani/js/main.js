//fixed icons(whatsapp & call)
$(document).ready(function (){
 // loading screen
$("#loading").fadeOut(1000,function(){
       $("body").css("overflow","auto")

})

})




 
 
